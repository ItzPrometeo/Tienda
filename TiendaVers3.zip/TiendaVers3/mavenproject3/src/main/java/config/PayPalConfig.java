/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

public class PayPalConfig {
    public static final String CLIENT_ID = "ASOraRCbvPwOXy-I2IH78QOQ-eUnUEhHhqzAAiwCbr4fV1QxXORVP0sS-8nrY_1RYlbBpd4dHhLIB4Me";
    public static final String SECRET    = "EIH-ZDO9dAqzHQv0WPuigtSW49zhl1eocLTjNhxMiaBR7AjSV3zxj-ICm_4mit6VTYKhRK5Frt9hmSwt";
    public static final String MODE      = "sandbox";
}
